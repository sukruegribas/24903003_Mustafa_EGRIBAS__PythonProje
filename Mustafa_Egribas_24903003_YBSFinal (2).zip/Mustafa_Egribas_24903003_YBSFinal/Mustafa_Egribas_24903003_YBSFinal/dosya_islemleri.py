"""
dosya_islemleri.py
------------------
Proje: Kişisel Finans ve Harcama Takip Sistemi
Öğrenci: Mustafa Şükrü Egrıbaş
Numara: 24903003
Ders: BGY210 – Python Programlama II

CSV okuma/yazma ve Excel dışa aktarma işlemlerini yönetir.
Excel export için openpyxl kullanılır; aylık özet tablosu
otomatik olarak oluşturulur ve her çalıştırmada güncellenir.
"""

import csv
import os
from datetime import datetime

from finans_modeli import FinansYoneticisi, Islem
from utils import baslik_yazdir

# Excel desteği için openpyxl
try:
    import openpyxl
    from openpyxl.styles import (
        Alignment,
        Border,
        Font,
        PatternFill,
        Side,
    )
    EXCEL_MEVCUT = True
except ImportError:
    EXCEL_MEVCUT = False

# CSV sütun başlıkları (sabit sıra korunmalı)
CSV_SUTUNLAR = ["id", "tip", "tutar", "tarih", "kategori", "aciklama"]

# Varsayılan dosya adları
VARSAYILAN_CSV = "finans_verileri.csv"
VARSAYILAN_EXCEL = "finans_raporu.xlsx"


# ---------------------------------------------------------------------------
# CSV işlemleri
# ---------------------------------------------------------------------------

def csv_kaydet(
    yonetici: FinansYoneticisi,
    dosya_adi: str = VARSAYILAN_CSV,
) -> bool:
    """
    Tüm gelir ve gider verilerini CSV dosyasına yazar.
    Mevcut dosyanın üzerine yazar (overwrite).

    Args:
        yonetici  : Merkezi FinansYoneticisi nesnesi.
        dosya_adi : Kaydedilecek CSV dosyasının adı/yolu.

    Returns:
        True → başarılı, False → hata oluştu.
    """
    baslik_yazdir("CSV Kaydet")
    try:
        tum_islemler = sorted(
            yonetici.tum_islemler(), key=lambda i: i.tarih
        )
        with open(dosya_adi, mode="w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=CSV_SUTUNLAR)
            writer.writeheader()
            for islem in tum_islemler:
                writer.writerow(islem.to_dict())

        print(f"  ✅ {len(tum_islemler)} işlem '{dosya_adi}' dosyasına kaydedildi.")
        return True

    except OSError as hata:
        print(f"  ❌ CSV kaydetme hatası: {hata}")
        return False


def csv_oku(
    yonetici: FinansYoneticisi,
    dosya_adi: str = VARSAYILAN_CSV,
) -> bool:
    """
    CSV dosyasından verileri okuyarak yöneticiye yükler.
    Mevcut listeye ekler (üstüne yazmaz).

    Args:
        yonetici  : Merkezi FinansYoneticisi nesnesi.
        dosya_adi : Okunacak CSV dosyasının adı/yolu.

    Returns:
        True → başarılı, False → hata / dosya yok.
    """
    baslik_yazdir("CSV Yükle")

    if not os.path.exists(dosya_adi):
        print(f"  ⚠ '{dosya_adi}' dosyası bulunamadı.")
        return False

    try:
        eklenen = 0
        mevcut_idler = {i.id for i in yonetici.tum_islemler()}

        with open(dosya_adi, mode="r", newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for satir in reader:
                islem_id = int(satir["id"])
                if islem_id in mevcut_idler:
                    continue  # Tekrar yüklemeyi engelle

                islem = Islem(
                    id=islem_id,
                    tutar=float(satir["tutar"]),
                    tarih=satir["tarih"],
                    aciklama=satir.get("aciklama", ""),
                    tip=satir["tip"],
                    kategori=satir.get("kategori", "Genel"),
                )

                if islem.tip == "gelir":
                    yonetici.gelir_ekle(islem)
                else:
                    yonetici.gider_ekle(islem)

                mevcut_idler.add(islem_id)
                eklenen += 1

        print(f"  ✅ {eklenen} yeni işlem '{dosya_adi}' dosyasından yüklendi.")
        return True

    except (OSError, KeyError, ValueError) as hata:
        print(f"  ❌ CSV okuma hatası: {hata}")
        return False


def csv_menu(yonetici: FinansYoneticisi) -> None:
    """
    Kullanıcıya CSV kaydetme veya yükleme seçeneği sunar.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.
    """
    baslik_yazdir("CSV İşlemleri")
    print("  1  ➜  CSV'ye Kaydet")
    print("  2  ➜  CSV'den Yükle")
    print("  0  ➜  Geri")

    secim = input("\n  Seçiminiz: ").strip()

    if secim == "1":
        dosya = input(f"  Dosya adı [{VARSAYILAN_CSV}]: ").strip() or VARSAYILAN_CSV
        csv_kaydet(yonetici, dosya)

    elif secim == "2":
        dosya = input(f"  Dosya adı [{VARSAYILAN_CSV}]: ").strip() or VARSAYILAN_CSV
        csv_oku(yonetici, dosya)

    elif secim != "0":
        print("  ⚠ Geçersiz seçim.")


# ---------------------------------------------------------------------------
# Excel işlemleri
# ---------------------------------------------------------------------------

def _stil_uygula_baslik(hucre, arka_plan: str = "1F4E79") -> None:
    """Başlık hücrelerine stil uygular (yardımcı iç fonksiyon)."""
    hucre.font = Font(bold=True, color="FFFFFF", size=11)
    hucre.fill = PatternFill("solid", fgColor=arka_plan)
    hucre.alignment = Alignment(horizontal="center", vertical="center")


def _ince_cerceve() -> Border:
    """İnce kenar çizgisi döndürür."""
    ince = Side(style="thin", color="CCCCCC")
    return Border(left=ince, right=ince, top=ince, bottom=ince)


def excel_aktar(
    yonetici: FinansYoneticisi,
    dosya_adi: str = VARSAYILAN_EXCEL,
) -> bool:
    """
    Tüm işlemleri, aylık özeti ve istatistikleri Excel dosyasına yazar.
    Dosya zaten mevcutsa günceller (üstüne yazar).

    Sayfalar:
        1. Tüm İşlemler  – ham veri tablosu
        2. Aylık Özet    – ay bazında gelir/gider/bakiye
        3. İstatistikler – genel sayısal özet

    Args:
        yonetici  : Merkezi FinansYoneticisi nesnesi.
        dosya_adi : Kaydedilecek Excel dosyasının adı/yolu.

    Returns:
        True → başarılı, False → hata oluştu.
    """
    baslik_yazdir("Excel'e Aktar")

    if not EXCEL_MEVCUT:
        print("  ❌ openpyxl kütüphanesi eksik. Yüklemek için:")
        print("     pip install openpyxl")
        return False

    tum_islemler = sorted(yonetici.tum_islemler(), key=lambda i: i.tarih)

    if not tum_islemler:
        print("  ⚠ Aktarılacak işlem bulunamadı.")
        return False

    try:
        wb = openpyxl.Workbook()

        # ── Sayfa 1: Tüm İşlemler ──────────────────────────────────────
        ws1 = wb.active
        ws1.title = "Tüm İşlemler"

        basliklar_1 = ["ID", "Tip", "Tutar (TL)", "Tarih", "Kategori", "Açıklama"]
        ws1.append(basliklar_1)

        for hucre in ws1[1]:
            _stil_uygula_baslik(hucre, "1F4E79")

        for islem in tum_islemler:
            renk = "E2EFDA" if islem.tip == "gelir" else "FCE4D6"
            satir = [
                islem.id,
                islem.tip.capitalize(),
                islem.tutar,
                islem.tarih,
                islem.kategori,
                islem.aciklama,
            ]
            ws1.append(satir)
            satir_no = ws1.max_row
            for hucre in ws1[satir_no]:
                hucre.fill = PatternFill("solid", fgColor=renk)
                hucre.border = _ince_cerceve()
                hucre.alignment = Alignment(horizontal="center")

            # Tutar sütununu para formatına al
            ws1.cell(row=satir_no, column=3).number_format = '#,##0.00 "TL"'

        # Sütun genişlikleri
        ws1.column_dimensions["A"].width = 6
        ws1.column_dimensions["B"].width = 10
        ws1.column_dimensions["C"].width = 16
        ws1.column_dimensions["D"].width = 14
        ws1.column_dimensions["E"].width = 16
        ws1.column_dimensions["F"].width = 30

        ws1.freeze_panes = "A2"  # Başlık satırını dondur

        # ── Sayfa 2: Aylık Özet ────────────────────────────────────────
        ws2 = wb.create_sheet("Aylık Özet")

        basliklar_2 = ["Ay", "Gelir (TL)", "Gider (TL)", "Net Bakiye (TL)"]
        ws2.append(basliklar_2)
        for hucre in ws2[1]:
            _stil_uygula_baslik(hucre, "375623")

        # Aylık toplam hesapla
        aylik: dict[str, dict[str, float]] = {}
        for islem in tum_islemler:
            ay = islem.ay  # YYYY-MM
            if ay not in aylik:
                aylik[ay] = {"gelir": 0.0, "gider": 0.0}
            aylik[ay][islem.tip] += islem.tutar

        for ay in sorted(aylik.keys()):
            gelir = aylik[ay]["gelir"]
            gider = aylik[ay]["gider"]
            bakiye = gelir - gider
            ws2.append([ay, gelir, gider, bakiye])
            satir_no = ws2.max_row
            for col in range(1, 5):
                hucre = ws2.cell(row=satir_no, column=col)
                hucre.border = _ince_cerceve()
                hucre.alignment = Alignment(horizontal="center")
            for col in (2, 3, 4):
                ws2.cell(row=satir_no, column=col).number_format = '#,##0.00 "TL"'
            # Bakiye renklendir
            bakiye_hucre = ws2.cell(row=satir_no, column=4)
            bakiye_hucre.font = Font(
                bold=True,
                color="375623" if bakiye >= 0 else "C00000",
            )

        for col in ("A", "B", "C", "D"):
            ws2.column_dimensions[col].width = 20
        ws2.freeze_panes = "A2"

        # ── Sayfa 3: İstatistikler ─────────────────────────────────────
        ws3 = wb.create_sheet("İstatistikler")

        ws3["A1"] = "📊 Genel Finansal Özet"
        ws3["A1"].font = Font(bold=True, size=14, color="1F4E79")
        ws3["A1"].alignment = Alignment(horizontal="left")

        ws3["A2"] = f"Oluşturulma: {datetime.now().strftime('%d.%m.%Y %H:%M')}"
        ws3["A2"].font = Font(italic=True, color="888888")

        istatistikler = [
            ("", ""),
            ("Toplam İşlem Sayısı", len(tum_islemler)),
            ("  Gelir İşlem Sayısı", len(yonetici.gelirler)),
            ("  Gider İşlem Sayısı", len(yonetici.giderler)),
            ("", ""),
            ("Toplam Gelir (TL)", yonetici.toplam_gelir()),
            ("Toplam Gider (TL)", yonetici.toplam_gider()),
            ("Net Bakiye (TL)", yonetici.bakiye()),
            ("", ""),
        ]

        # Ortalama, min, max hesapla
        if yonetici.gelirler:
            gelir_tutarlar = [g.tutar for g in yonetici.gelirler]
            istatistikler += [
                ("Ortalama Gelir (TL)", sum(gelir_tutarlar) / len(gelir_tutarlar)),
                ("En Yüksek Gelir (TL)", max(gelir_tutarlar)),
                ("En Düşük Gelir (TL)", min(gelir_tutarlar)),
                ("", ""),
            ]

        if yonetici.giderler:
            gider_tutarlar = [g.tutar for g in yonetici.giderler]
            istatistikler += [
                ("Ortalama Gider (TL)", sum(gider_tutarlar) / len(gider_tutarlar)),
                ("En Yüksek Gider (TL)", max(gider_tutarlar)),
                ("En Düşük Gider (TL)", min(gider_tutarlar)),
            ]

        baslik_satir = 4
        ws3.cell(row=baslik_satir, column=1, value="Gösterge").font = Font(
            bold=True, color="FFFFFF"
        )
        ws3.cell(row=baslik_satir, column=2, value="Değer").font = Font(
            bold=True, color="FFFFFF"
        )
        for col in (1, 2):
            ws3.cell(row=baslik_satir, column=col).fill = PatternFill(
                "solid", fgColor="1F4E79"
            )
            ws3.cell(row=baslik_satir, column=col).alignment = Alignment(
                horizontal="center"
            )

        for offset, (gosterge, deger) in enumerate(istatistikler, start=baslik_satir + 1):
            ws3.cell(row=offset, column=1, value=gosterge)
            ws3.cell(row=offset, column=2, value=deger)
            if isinstance(deger, float):
                ws3.cell(row=offset, column=2).number_format = '#,##0.00 "TL"'
                if "Bakiye" in gosterge:
                    ws3.cell(row=offset, column=2).font = Font(
                        bold=True,
                        color="375623" if deger >= 0 else "C00000",
                    )
            if gosterge:
                ws3.cell(row=offset, column=1).border = _ince_cerceve()
                ws3.cell(row=offset, column=2).border = _ince_cerceve()

        ws3.column_dimensions["A"].width = 28
        ws3.column_dimensions["B"].width = 20

        # ── Kaydet ────────────────────────────────────────────────────
        wb.save(dosya_adi)
        print(f"  ✅ Excel raporu '{dosya_adi}' olarak kaydedildi.")
        print(f"     • Sayfa 1 : Tüm İşlemler  ({len(tum_islemler)} satır)")
        print(f"     • Sayfa 2 : Aylık Özet     ({len(aylik)} ay)")
        print("     • Sayfa 3 : İstatistikler")
        return True

    except OSError as hata:
        print(f"  ❌ Excel kaydetme hatası: {hata}")
        return False


def excel_menu(yonetici: FinansYoneticisi) -> None:
    """
    Kullanıcıya Excel dosya adı sorar ve dışa aktarma başlatır.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.
    """
    dosya = (
        input(f"  Dosya adı [{VARSAYILAN_EXCEL}]: ").strip() or VARSAYILAN_EXCEL
    )
    if not dosya.endswith(".xlsx"):
        dosya += ".xlsx"
    excel_aktar(yonetici, dosya)
