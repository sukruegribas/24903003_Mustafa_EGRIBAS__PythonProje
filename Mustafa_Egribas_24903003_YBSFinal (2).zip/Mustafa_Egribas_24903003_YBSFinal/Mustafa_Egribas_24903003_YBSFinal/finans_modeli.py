"""
finans_modeli.py
----------------
Proje: Kişisel Finans ve Harcama Takip Sistemi
Öğrenci: Mustafa Şükrü Egrıbaş
Numara: 24903003
Ders: BGY210 – Python Programlama II

Bu modül, uygulamanın nesne tabanlı temel yapısını içerir.
Tüm gelir ve gider kayıtları 'Islem' sınıfının örnekleri olarak oluşturulur.
"""


class Islem:
    """
    Tek bir finansal işlemi (gelir veya gider) temsil eden sınıf.

    Attributes:
        id       (int)   : Benzersiz işlem kimlik numarası.
        tutar    (float) : İşlem tutarı (TL cinsinden).
        tarih    (str)   : İşlem tarihi – YYYY-MM-DD formatında.
        aciklama (str)   : İşlemi tanımlayan kısa açıklama.
        tip      (str)   : 'gelir' veya 'gider'.
        kategori (str)   : İşlem kategorisi (örn. Maaş, Kira, Market).
    """

    def __init__(
        self,
        id: int,
        tutar: float,
        tarih: str,
        aciklama: str,
        tip: str,
        kategori: str = "Genel",
    ) -> None:
        self.id = id
        self.tutar = tutar
        self.tarih = tarih
        self.aciklama = aciklama
        self.tip = tip.lower()          # 'gelir' veya 'gider' olarak normalize et
        self.kategori = kategori

    # ------------------------------------------------------------------
    # Yerleşik metotlar
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        """Nesnenin geliştirici dostu metin temsili."""
        return (
            f"Islem(id={self.id}, tip='{self.tip}', tutar={self.tutar:.2f} TL, "
            f"tarih='{self.tarih}', kategori='{self.kategori}', "
            f"aciklama='{self.aciklama}')"
        )

    def __str__(self) -> str:
        """Kullanıcıya gösterilecek okunabilir metin temsili."""
        yon = "⬆ GELİR" if self.tip == "gelir" else "⬇ GİDER"
        return (
            f"[{self.id:>4}] {yon} | {self.tarih} | "
            f"{self.tutar:>10.2f} TL | {self.kategori:<12} | {self.aciklama}"
        )

    def to_dict(self) -> dict:
        """
        Nesneyi sözlük (dict) yapısına dönüştürür.
        CSV kaydetme ve DataFrame oluşturma işlemlerinde kullanılır.
        """
        return {
            "id": self.id,
            "tip": self.tip,
            "tutar": self.tutar,
            "tarih": self.tarih,
            "kategori": self.kategori,
            "aciklama": self.aciklama,
        }

    # ------------------------------------------------------------------
    # Yardımcı özellikler
    # ------------------------------------------------------------------

    @property
    def ay(self) -> str:
        """Tarihin 'YYYY-MM' kısmını döndürür (aylık analiz için)."""
        return self.tarih[:7]

    @property
    def yil(self) -> str:
        """Tarihin yıl kısmını döndürür."""
        return self.tarih[:4]


class FinansYoneticisi:
    """
    Tüm gelir ve gider listelerini bir arada tutan yönetici sınıfı.
    İşlem ekleme, silme ve sorgulama işlemlerini merkezi olarak yönetir.
    """

    def __init__(self) -> None:
        self.gelirler: list[Islem] = []
        self.giderler: list[Islem] = []

    # ------------------------------------------------------------------
    # Ekleme işlemleri
    # ------------------------------------------------------------------

    def gelir_ekle(self, islem: "Islem") -> None:
        """Listeye yeni bir gelir işlemi ekler."""
        self.gelirler.append(islem)

    def gider_ekle(self, islem: "Islem") -> None:
        """Listeye yeni bir gider işlemi ekler."""
        self.giderler.append(islem)

    # ------------------------------------------------------------------
    # Silme işlemi
    # ------------------------------------------------------------------

    def islem_sil(self, islem_id: int) -> bool:
        """
        Verilen ID'ye sahip işlemi bulur ve siler.

        Returns:
            True  → işlem bulunup silindi.
            False → işlem bulunamadı.
        """
        for liste in (self.gelirler, self.giderler):
            for islem in liste:
                if islem.id == islem_id:
                    liste.remove(islem)
                    return True
        return False

    # ------------------------------------------------------------------
    # Sorgulama
    # ------------------------------------------------------------------

    def tum_islemler(self) -> list["Islem"]:
        """Gelir ve gider listelerini birleştirerek döndürür."""
        return self.gelirler + self.giderler

    def id_ile_bul(self, islem_id: int) -> "Islem | None":
        """Belirtilen ID'ye sahip işlemi döndürür; bulamazsa None."""
        for islem in self.tum_islemler():
            if islem.id == islem_id:
                return islem
        return None

    # ------------------------------------------------------------------
    # Özet bilgiler
    # ------------------------------------------------------------------

    def toplam_gelir(self) -> float:
        """Tüm gelirlerin toplamını döndürür."""
        return sum(g.tutar for g in self.gelirler)

    def toplam_gider(self) -> float:
        """Tüm giderlerin toplamını döndürür."""
        return sum(g.tutar for g in self.giderler)

    def bakiye(self) -> float:
        """Net bakiyeyi (gelir - gider) döndürür."""
        return self.toplam_gelir() - self.toplam_gider()

    def __repr__(self) -> str:
        return (
            f"FinansYoneticisi("
            f"gelir_sayisi={len(self.gelirler)}, "
            f"gider_sayisi={len(self.giderler)}, "
            f"bakiye={self.bakiye():.2f} TL)"
        )
