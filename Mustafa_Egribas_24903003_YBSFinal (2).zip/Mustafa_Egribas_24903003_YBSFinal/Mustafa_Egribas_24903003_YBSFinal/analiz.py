"""
analiz.py
---------
Proje: Kişisel Finans ve Harcama Takip Sistemi
Öğrenci: Mustafa Şükrü Egrıbaş
Numara: 24903003
Ders: BGY210 – Python Programlama II

Pandas ve NumPy kullanarak veri analizi fonksiyonlarını içerir.
DataFrame oluşturma, aylık analiz, istatistik hesaplama ve
aylık gelir-gider tablosunu manuel güncelleme burada yapılır.
"""

import numpy as np
import pandas as pd

from finans_modeli import FinansYoneticisi
from utils import baslik_yazdir


# ---------------------------------------------------------------------------
# DataFrame oluşturma
# ---------------------------------------------------------------------------

def verileri_dataframe_yap(yonetici: FinansYoneticisi) -> pd.DataFrame:
    """
    Gelir ve gider listelerini birleştirerek pandas DataFrame'e dönüştürür.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.

    Returns:
        Tarih sütunu datetime tipinde olan ve 'ay' sütunu eklenmiş DataFrame.
        Veri yoksa boş DataFrame döner.
    """
    tum_islemler = yonetici.tum_islemler()

    if not tum_islemler:
        return pd.DataFrame(
            columns=["id", "tip", "tutar", "tarih", "kategori", "aciklama", "ay"]
        )

    satirlar = [islem.to_dict() for islem in tum_islemler]
    df = pd.DataFrame(satirlar)

    # Tarih sütununu datetime'a çevir
    df["tarih"] = pd.to_datetime(df["tarih"])

    # Aylık analiz için ek sütun
    df["ay"] = df["tarih"].dt.to_period("M").astype(str)

    # Sıralama
    df = df.sort_values("tarih").reset_index(drop=True)

    return df


# ---------------------------------------------------------------------------
# Temel analiz fonksiyonları
# ---------------------------------------------------------------------------

def toplam_gelir_gider(df: pd.DataFrame) -> dict[str, float]:
    """
    DataFrame üzerinden toplam gelir, gider ve net bakiye hesaplar.

    Args:
        df: verileri_dataframe_yap() ile oluşturulmuş DataFrame.

    Returns:
        {'gelir': float, 'gider': float, 'bakiye': float} sözlüğü.
    """
    if df.empty:
        return {"gelir": 0.0, "gider": 0.0, "bakiye": 0.0}

    gelir = float(df[df["tip"] == "gelir"]["tutar"].sum())
    gider = float(df[df["tip"] == "gider"]["tutar"].sum())
    return {"gelir": gelir, "gider": gider, "bakiye": gelir - gider}


def aylik_analiz(df: pd.DataFrame) -> pd.DataFrame:
    """
    Verileri aya göre gruplayarak aylık özet tablo oluşturur.

    Her ay için şu bilgiler hesaplanır:
        - Toplam gelir
        - Toplam gider
        - Net bakiye
        - İşlem sayısı

    Args:
        df: verileri_dataframe_yap() ile oluşturulmuş DataFrame.

    Returns:
        Aylık özet DataFrame; boş ise boş DataFrame.
    """
    if df.empty:
        return pd.DataFrame()

    gelir_df = df[df["tip"] == "gelir"].groupby("ay")["tutar"].sum().rename("Gelir (TL)")
    gider_df = df[df["tip"] == "gider"].groupby("ay")["tutar"].sum().rename("Gider (TL)")
    sayi_df = df.groupby("ay")["id"].count().rename("İşlem Sayısı")

    ozet = pd.concat([gelir_df, gider_df, sayi_df], axis=1).fillna(0)
    ozet["Net Bakiye (TL)"] = ozet["Gelir (TL)"] - ozet["Gider (TL)"]
    ozet.index.name = "Ay"

    return ozet.sort_index()


def numpy_istatistik(df: pd.DataFrame) -> dict[str, dict[str, float]]:
    """
    NumPy kullanarak gelir ve gider üzerinde istatistiksel hesaplamalar yapar.

    Hesaplanan değerler: ortalama, minimum, maksimum, standart sapma, medyan.

    Args:
        df: verileri_dataframe_yap() ile oluşturulmuş DataFrame.

    Returns:
        {'gelir': {...}, 'gider': {...}} iç içe sözlük yapısı.
    """
    sonuc: dict[str, dict[str, float]] = {}

    for tip in ("gelir", "gider"):
        tutarlar = df[df["tip"] == tip]["tutar"].values.astype(float)

        if len(tutarlar) == 0:
            sonuc[tip] = {
                "ortalama": 0.0,
                "minimum": 0.0,
                "maksimum": 0.0,
                "std_sapma": 0.0,
                "medyan": 0.0,
                "toplam": 0.0,
            }
        else:
            sonuc[tip] = {
                "ortalama": float(np.mean(tutarlar)),
                "minimum": float(np.min(tutarlar)),
                "maksimum": float(np.max(tutarlar)),
                "std_sapma": float(np.std(tutarlar)),
                "medyan": float(np.median(tutarlar)),
                "toplam": float(np.sum(tutarlar)),
            }

    return sonuc


def kategori_analizi(df: pd.DataFrame) -> pd.DataFrame:
    """
    Her kategori için toplam harcama/gelir miktarını hesaplar.

    Args:
        df: verileri_dataframe_yap() ile oluşturulmuş DataFrame.

    Returns:
        Kategoriye göre gruplandırılmış özet DataFrame.
    """
    if df.empty:
        return pd.DataFrame()

    return (
        df.groupby(["tip", "kategori"])["tutar"]
        .agg(["sum", "count", "mean"])
        .rename(columns={"sum": "Toplam", "count": "Adet", "mean": "Ortalama"})
        .sort_values("Toplam", ascending=False)
    )


# ---------------------------------------------------------------------------
# Konsol çıktısı
# ---------------------------------------------------------------------------

def analiz_goster(yonetici: FinansYoneticisi) -> None:
    """
    Tüm analiz sonuçlarını biçimli şekilde ekrana yazdırır.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.
    """
    baslik_yazdir("Finansal Analiz")

    df = verileri_dataframe_yap(yonetici)

    if df.empty:
        print("  ℹ Analiz için yeterli veri yok.")
        return

    # ── Genel özet ──────────────────────────────────────────────────────
    toplamlar = toplam_gelir_gider(df)
    print("\n  ◆ GENEL ÖZET")
    print(f"  {'Toplam Gelir':<25}: {toplamlar['gelir']:>12.2f} TL")
    print(f"  {'Toplam Gider':<25}: {toplamlar['gider']:>12.2f} TL")
    bakiye = toplamlar["bakiye"]
    isaret = "✅" if bakiye >= 0 else "⚠ "
    print(f"  {isaret} {'Net Bakiye':<23}: {bakiye:>12.2f} TL")

    # ── Aylık analiz ────────────────────────────────────────────────────
    print("\n  ◆ AYLIK ÖZET")
    aylik_df = aylik_analiz(df)
    if not aylik_df.empty:
        # Sütun başlıklarını yazdır
        print(
            f"  {'Ay':<10} | {'Gelir (TL)':>14} | {'Gider (TL)':>14} | "
            f"{'Net Bakiye (TL)':>16} | {'Adet':>5}"
        )
        print("  " + "-" * 68)
        for ay, satir in aylik_df.iterrows():
            net = satir["Net Bakiye (TL)"]
            isaret = "✅" if net >= 0 else "⚠"
            print(
                f"  {str(ay):<10} | {satir['Gelir (TL)']:>14.2f} | "
                f"{satir['Gider (TL)']:>14.2f} | {net:>15.2f} {isaret} | "
                f"{int(satir['İşlem Sayısı']):>5}"
            )

    # ── NumPy istatistikleri ─────────────────────────────────────────────
    print("\n  ◆ İSTATİSTİKSEL ANALİZ (NumPy)")
    istatistikler = numpy_istatistik(df)
    for tip, degerler in istatistikler.items():
        print(f"\n    [{tip.upper()}]")
        for ad, deger in degerler.items():
            print(f"    {ad.replace('_', ' ').capitalize():<14}: {deger:>12.2f} TL")

    # ── Kategori analizi ──────────────────────────────────────────────────
    print("\n  ◆ KATEGORİ ANALİZİ")
    kat_df = kategori_analizi(df)
    if not kat_df.empty:
        print(
            f"  {'Tip':<8} | {'Kategori':<16} | {'Toplam (TL)':>14} | "
            f"{'Adet':>5} | {'Ortalama (TL)':>14}"
        )
        print("  " + "-" * 68)
        for (tip, kategori), satir in kat_df.iterrows():
            print(
                f"  {tip.capitalize():<8} | {kategori:<16} | "
                f"{satir['Toplam']:>14.2f} | {int(satir['Adet']):>5} | "
                f"{satir['Ortalama']:>14.2f}"
            )


# ---------------------------------------------------------------------------
# Manuel aylık tablo güncelleme
# ---------------------------------------------------------------------------

def aylik_tablo_guncelle(yonetici: FinansYoneticisi) -> None:
    """
    Aylık gelir-gider tablosunu ekranda gösterir ve isteğe bağlı
    bir metin dosyasına ('aylik_ozet.txt') yazar.
    Bu fonksiyon her çalıştırıldığında tabloyu yeniden hesaplar
    ve dosyayı günceller – veri değişse bile tablo güncel kalır.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.
    """
    baslik_yazdir("Aylık Tablo Güncelle")

    df = verileri_dataframe_yap(yonetici)
    if df.empty:
        print("  ℹ Tablo için veri yok.")
        return

    aylik_df = aylik_analiz(df)

    # Ekrana yazdır
    print(f"\n  {'AY':<10} | {'GELİR (TL)':>14} | {'GİDER (TL)':>14} | {'NET BAKİYE':>14}")
    print("  " + "─" * 58)
    for ay, satir in aylik_df.iterrows():
        net = satir["Net Bakiye (TL)"]
        isaret = "+" if net >= 0 else "-"
        print(
            f"  {str(ay):<10} | {satir['Gelir (TL)']:>14.2f} | "
            f"{satir['Gider (TL)']:>14.2f} | {isaret}{abs(net):>13.2f}"
        )

    # Dosyaya kaydet
    dosya_adi = "aylik_ozet.txt"
    try:
        with open(dosya_adi, "w", encoding="utf-8") as f:
            f.write("AYLIK GELİR-GİDER ÖZETİ\n")
            f.write("=" * 58 + "\n")
            f.write(f"{'AY':<10} | {'GELİR (TL)':>14} | {'GİDER (TL)':>14} | {'NET BAKİYE':>14}\n")
            f.write("-" * 58 + "\n")
            for ay, satir in aylik_df.iterrows():
                net = satir["Net Bakiye (TL)"]
                isaret = "+" if net >= 0 else "-"
                f.write(
                    f"{str(ay):<10} | {satir['Gelir (TL)']:>14.2f} | "
                    f"{satir['Gider (TL)']:>14.2f} | {isaret}{abs(net):>13.2f}\n"
                )
        print(f"\n  ✅ Tablo '{dosya_adi}' dosyasına güncellendi.")
    except OSError as hata:
        print(f"  ❌ Dosya yazma hatası: {hata}")
