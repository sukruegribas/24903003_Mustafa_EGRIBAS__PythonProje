"""
islem_yonetimi.py
-----------------
Proje: Kişisel Finans ve Harcama Takip Sistemi
Öğrenci: Mustafa Şükrü Egrıbaş
Numara: 24903003
Ders: BGY210 – Python Programlama II

Gelir ekleme, gider ekleme, listeleme ve silme işlemlerini
yönetir. Kullanıcıdan veri alır ve doğrulama için utils.py'yi kullanır.
"""

from finans_modeli import FinansYoneticisi, Islem
from utils import (
    baslik_yazdir,
    kategori_sec,
    kullanici_tarih_al,
    kullanici_tutar_al,
    onay_al,
    tum_listelerden_yeni_id,
)


# ---------------------------------------------------------------------------
# Gelir işlemleri
# ---------------------------------------------------------------------------

def gelir_ekle(yonetici: FinansYoneticisi) -> Islem | None:
    """
    Kullanıcıdan gelir bilgilerini alır, doğrular ve kayıt oluşturur.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.

    Returns:
        Eklenen Islem nesnesi; işlem iptal edilirse None.
    """
    baslik_yazdir("Yeni Gelir Ekle")

    try:
        tutar = kullanici_tutar_al("  Gelir Tutarı (TL): ")
        tarih = kullanici_tarih_al()
        aciklama = input("  Açıklama: ").strip() or "Belirtilmemiş"
        kategori = kategori_sec("gelir")

        yeni_id = tum_listelerden_yeni_id(yonetici.gelirler, yonetici.giderler)
        islem = Islem(
            id=yeni_id,
            tutar=tutar,
            tarih=tarih,
            aciklama=aciklama,
            tip="gelir",
            kategori=kategori,
        )

        print(f"\n  Eklenecek işlem:\n  {islem}")
        if onay_al("  Kaydetmek istiyor musunuz? (e/h): "):
            yonetici.gelir_ekle(islem)
            print(f"  ✅ Gelir başarıyla eklendi. ID: {yeni_id}")
            return islem
        else:
            print("  ❌ İşlem iptal edildi.")
            return None

    except KeyboardInterrupt:
        print("\n  ⚠ İşlem kullanıcı tarafından kesildi.")
        return None


# ---------------------------------------------------------------------------
# Gider işlemleri
# ---------------------------------------------------------------------------

def gider_ekle(yonetici: FinansYoneticisi) -> Islem | None:
    """
    Kullanıcıdan gider bilgilerini alır, doğrular ve kayıt oluşturur.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.

    Returns:
        Eklenen Islem nesnesi; işlem iptal edilirse None.
    """
    baslik_yazdir("Yeni Gider Ekle")

    try:
        tutar = kullanici_tutar_al("  Gider Tutarı (TL): ")
        tarih = kullanici_tarih_al()
        aciklama = input("  Açıklama: ").strip() or "Belirtilmemiş"
        kategori = kategori_sec("gider")

        yeni_id = tum_listelerden_yeni_id(yonetici.gelirler, yonetici.giderler)
        islem = Islem(
            id=yeni_id,
            tutar=tutar,
            tarih=tarih,
            aciklama=aciklama,
            tip="gider",
            kategori=kategori,
        )

        print(f"\n  Eklenecek işlem:\n  {islem}")
        if onay_al("  Kaydetmek istiyor musunuz? (e/h): "):
            yonetici.gider_ekle(islem)
            print(f"  ✅ Gider başarıyla eklendi. ID: {yeni_id}")
            return islem
        else:
            print("  ❌ İşlem iptal edildi.")
            return None

    except KeyboardInterrupt:
        print("\n  ⚠ İşlem kullanıcı tarafından kesildi.")
        return None


# ---------------------------------------------------------------------------
# Listeleme
# ---------------------------------------------------------------------------

def islemleri_listele(yonetici: FinansYoneticisi) -> None:
    """
    Tüm gelir ve gider kayıtlarını tarih sırasına göre düzenli listeler.
    Ayrıca toplam bakiye özetini gösterir.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.
    """
    baslik_yazdir("Tüm İşlemler")

    tum = sorted(yonetici.tum_islemler(), key=lambda i: i.tarih)

    if not tum:
        print("  ℹ Henüz kayıtlı işlem bulunmuyor.")
        return

    # Başlık satırı
    print(
        f"  {'ID':>4} | {'TİP':<8} | {'TARİH':<10} | "
        f"{'TUTAR (TL)':>12} | {'KATEGORİ':<14} | AÇIKLAMA"
    )
    print("  " + "-" * 80)

    for islem in tum:
        yon = "⬆ GELİR" if islem.tip == "gelir" else "⬇ GİDER"
        print(
            f"  {islem.id:>4} | {yon:<8} | {islem.tarih:<10} | "
            f"{islem.tutar:>12.2f} | {islem.kategori:<14} | {islem.aciklama}"
        )

    # Özet
    print("  " + "═" * 80)
    print(f"  {'Toplam Gelir':>40} : {yonetici.toplam_gelir():>12.2f} TL")
    print(f"  {'Toplam Gider':>40} : {yonetici.toplam_gider():>12.2f} TL")
    bakiye = yonetici.bakiye()
    isaret = "✅" if bakiye >= 0 else "⚠"
    print(f"  {isaret} {'Net Bakiye':>38} : {bakiye:>12.2f} TL")


# ---------------------------------------------------------------------------
# Silme
# ---------------------------------------------------------------------------

def islem_sil(yonetici: FinansYoneticisi) -> None:
    """
    Kullanıcıdan ID alarak ilgili işlemi listeden siler.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.
    """
    baslik_yazdir("İşlem Sil")

    tum = yonetici.tum_islemler()
    if not tum:
        print("  ℹ Silinecek kayıt yok.")
        return

    islemleri_listele(yonetici)

    try:
        id_str = input("\n  Silinecek işlemin ID'si (iptal: 0): ").strip()
        if id_str == "0":
            print("  ❌ Silme işlemi iptal edildi.")
            return

        if not id_str.isdigit():
            print("  ⚠ Geçersiz ID.")
            return

        islem_id = int(id_str)
        islem = yonetici.id_ile_bul(islem_id)

        if islem is None:
            print(f"  ⚠ ID {islem_id} ile eşleşen işlem bulunamadı.")
            return

        print(f"\n  Silinecek işlem: {islem}")
        if onay_al("  Emin misiniz? Bu işlem geri alınamaz. (e/h): "):
            yonetici.islem_sil(islem_id)
            print(f"  ✅ ID {islem_id} başarıyla silindi.")
        else:
            print("  ❌ Silme iptal edildi.")

    except KeyboardInterrupt:
        print("\n  ⚠ İşlem kullanıcı tarafından kesildi.")
