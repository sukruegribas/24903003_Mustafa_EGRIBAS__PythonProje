"""
gorsellestirme.py
-----------------
Proje: Kişisel Finans ve Harcama Takip Sistemi
Öğrenci: Mustafa Şükrü Egrıbaş
Numara: 24903003
Ders: BGY210 – Python Programlama II

Matplotlib ve Seaborn kullanarak görselleştirme fonksiyonları.
Çizgi grafik, sütun grafik, pasta grafik ve kategori grafikleri.
"""

import os

import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns

from analiz import aylik_analiz, kategori_analizi, verileri_dataframe_yap
from finans_modeli import FinansYoneticisi
from utils import baslik_yazdir

# ---------------------------------------------------------------------------
# Genel görsel ayarlar
# ---------------------------------------------------------------------------

RENK_GELİR = "#2ecc71"   # yeşil
RENK_GİDER = "#e74c3c"   # kırmızı
RENK_BAKİYE = "#3498db"  # mavi
CIKTI_KLASORU = "grafikler"


def _klasor_hazirla() -> str:
    """Grafiklerin kaydedileceği klasörü oluşturur; adını döndürür."""
    os.makedirs(CIKTI_KLASORU, exist_ok=True)
    return CIKTI_KLASORU


def _grafik_kaydet(fig: plt.Figure, dosya_adi: str) -> str:
    """
    Grafik figürünü PNG olarak kaydeder ve dosya yolunu döndürür.

    Args:
        fig      : Kaydedilecek Matplotlib Figure nesnesi.
        dosya_adi: Kayıt adı (uzantısız).

    Returns:
        Kaydedilen dosyanın tam yolu.
    """
    klasor = _klasor_hazirla()
    yol = os.path.join(klasor, f"{dosya_adi}.png")
    fig.savefig(yol, dpi=150, bbox_inches="tight")
    print(f"  💾 Grafik kaydedildi: {yol}")
    return yol


# ---------------------------------------------------------------------------
# Grafik fonksiyonları
# ---------------------------------------------------------------------------

def aylik_grafik(yonetici: FinansYoneticisi) -> None:
    """
    Aylık gelir ve giderleri karşılaştıran çizgi grafiği oluşturur.
    Grafik hem ekranda gösterilir hem PNG olarak kaydedilir.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.
    """
    df = verileri_dataframe_yap(yonetici)
    if df.empty:
        print("  ⚠ Grafik için yeterli veri yok.")
        return

    aylik_df = aylik_analiz(df)
    if aylik_df.empty:
        print("  ⚠ Aylık veri bulunamadı.")
        return

    sns.set_theme(style="whitegrid", palette="muted")
    fig, ax = plt.subplots(figsize=(10, 5))

    aylar = aylik_df.index.astype(str).tolist()
    x = range(len(aylar))

    ax.plot(
        x, aylik_df["Gelir (TL)"],
        marker="o", linewidth=2.5, color=RENK_GELİR, label="Gelir"
    )
    ax.plot(
        x, aylik_df["Gider (TL)"],
        marker="s", linewidth=2.5, color=RENK_GİDER, label="Gider", linestyle="--"
    )
    ax.plot(
        x, aylik_df["Net Bakiye (TL)"],
        marker="^", linewidth=2, color=RENK_BAKİYE, label="Net Bakiye", linestyle=":"
    )

    ax.set_xticks(x)
    ax.set_xticklabels(aylar, rotation=30, ha="right")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v:,.0f} TL"))
    ax.axhline(0, color="gray", linewidth=0.8, linestyle="-")

    ax.set_title("Aylık Gelir – Gider Karşılaştırması", fontsize=14, fontweight="bold")
    ax.set_xlabel("Ay")
    ax.set_ylabel("Tutar (TL)")
    ax.legend()

    plt.tight_layout()
    _grafik_kaydet(fig, "aylik_cizgi_grafik")
    plt.show()
    plt.close(fig)


def gelir_gider_bar(yonetici: FinansYoneticisi) -> None:
    """
    Toplam gelir ve toplam gideri karşılaştıran sütun grafiği oluşturur.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.
    """
    df = verileri_dataframe_yap(yonetici)
    if df.empty:
        print("  ⚠ Grafik için yeterli veri yok.")
        return

    from analiz import toplam_gelir_gider

    toplamlar = toplam_gelir_gider(df)

    sns.set_theme(style="whitegrid")
    fig, ax = plt.subplots(figsize=(6, 5))

    kategoriler = ["Gelir", "Gider"]
    degerler = [toplamlar["gelir"], toplamlar["gider"]]
    renkler = [RENK_GELİR, RENK_GİDER]

    bars = ax.bar(kategoriler, degerler, color=renkler, width=0.5, edgecolor="white")

    # Her barın üstüne tutar yaz
    for bar, deger in zip(bars, degerler):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + max(degerler) * 0.01,
            f"{deger:,.2f} TL",
            ha="center", va="bottom", fontweight="bold", fontsize=10,
        )

    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v:,.0f} TL"))
    ax.set_title("Toplam Gelir – Gider Karşılaştırması", fontsize=13, fontweight="bold")
    ax.set_ylabel("Tutar (TL)")

    # Bakiye bilgisi
    bakiye = toplamlar["bakiye"]
    renk_bakiye = RENK_GELİR if bakiye >= 0 else RENK_GİDER
    ax.text(
        0.5, 0.97,
        f"Net Bakiye: {bakiye:+,.2f} TL",
        transform=ax.transAxes, ha="center", va="top",
        fontsize=11, color=renk_bakiye, fontweight="bold",
    )

    plt.tight_layout()
    _grafik_kaydet(fig, "gelir_gider_bar")
    plt.show()
    plt.close(fig)


def pasta_grafik(yonetici: FinansYoneticisi) -> None:
    """
    Gider kategorilerinin dağılımını gösteren pasta grafiği oluşturur.
    Gider yoksa gelir dağılımı gösterilir.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.
    """
    df = verileri_dataframe_yap(yonetici)
    if df.empty:
        print("  ⚠ Grafik için yeterli veri yok.")
        return

    # Gider kategorisi tercihli; yoksa gelir göster
    for tip in ("gider", "gelir"):
        alt_df = df[df["tip"] == tip]
        if not alt_df.empty:
            break
    else:
        print("  ⚠ Pasta grafik için veri yok.")
        return

    kategori_grp = alt_df.groupby("kategori")["tutar"].sum().sort_values(ascending=False)

    fig, ax = plt.subplots(figsize=(8, 6))
    renkler = plt.cm.Set3.colors  # type: ignore[attr-defined]

    wedges, texts, autotexts = ax.pie(
        kategori_grp.values,
        labels=kategori_grp.index,
        autopct="%1.1f%%",
        colors=renkler[: len(kategori_grp)],
        startangle=140,
        pctdistance=0.82,
    )

    for text in autotexts:
        text.set_fontsize(9)
        text.set_fontweight("bold")

    baslik = "Gider Kategori Dağılımı" if tip == "gider" else "Gelir Kategori Dağılımı"
    ax.set_title(baslik, fontsize=13, fontweight="bold")

    plt.tight_layout()
    _grafik_kaydet(fig, "pasta_grafik")
    plt.show()
    plt.close(fig)


def kategori_bar(yonetici: FinansYoneticisi) -> None:
    """
    Her kategorideki toplam harcamayı gösteren yatay sütun grafiği.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.
    """
    df = verileri_dataframe_yap(yonetici)
    if df.empty:
        print("  ⚠ Grafik için yeterli veri yok.")
        return

    kat_df = kategori_analizi(df)
    if kat_df.empty:
        print("  ⚠ Kategori verisi bulunamadı.")
        return

    # Multi-index'i düzleştir
    kat_df = kat_df.reset_index()
    kat_df["Etiket"] = kat_df["tip"].str.capitalize() + " / " + kat_df["kategori"]
    kat_df = kat_df.sort_values("Toplam")

    renkler = [
        RENK_GELİR if tip == "gelir" else RENK_GİDER
        for tip in kat_df["tip"]
    ]

    fig, ax = plt.subplots(figsize=(9, max(4, len(kat_df) * 0.45)))
    bars = ax.barh(kat_df["Etiket"], kat_df["Toplam"], color=renkler)

    for bar in bars:
        genislik = bar.get_width()
        ax.text(
            genislik + max(kat_df["Toplam"]) * 0.005,
            bar.get_y() + bar.get_height() / 2,
            f"{genislik:,.0f} TL",
            va="center", ha="left", fontsize=8,
        )

    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v:,.0f}"))
    ax.set_title("Kategoriye Göre Toplam Tutar", fontsize=13, fontweight="bold")
    ax.set_xlabel("Tutar (TL)")

    from matplotlib.patches import Patch

    legend_elemanlar = [
        Patch(color=RENK_GELİR, label="Gelir"),
        Patch(color=RENK_GİDER, label="Gider"),
    ]
    ax.legend(handles=legend_elemanlar, loc="lower right")

    plt.tight_layout()
    _grafik_kaydet(fig, "kategori_bar")
    plt.show()
    plt.close(fig)


# ---------------------------------------------------------------------------
# Grafik menüsü
# ---------------------------------------------------------------------------

def grafik_menu(yonetici: FinansYoneticisi) -> None:
    """
    Kullanıcıya grafik seçeneklerini sunar.

    Args:
        yonetici: Merkezi FinansYoneticisi nesnesi.
    """
    baslik_yazdir("Grafik Göster")
    print("  1  ➜  Aylık Gelir–Gider Çizgi Grafik")
    print("  2  ➜  Toplam Gelir–Gider Sütun Grafik")
    print("  3  ➜  Kategori Pasta Grafik")
    print("  4  ➜  Kategori Sütun Grafik")
    print("  5  ➜  Tüm Grafikleri Göster")
    print("  0  ➜  Geri")

    secim = input("\n  Seçiminiz: ").strip()

    grafik_map = {
        "1": aylik_grafik,
        "2": gelir_gider_bar,
        "3": pasta_grafik,
        "4": kategori_bar,
    }

    if secim == "5":
        for fonk in grafik_map.values():
            fonk(yonetici)
    elif secim in grafik_map:
        grafik_map[secim](yonetici)
    elif secim != "0":
        print("  ⚠ Geçersiz seçim.")
