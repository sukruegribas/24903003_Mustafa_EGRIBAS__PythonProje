"""
main.py
-------
Proje: Kişisel Finans ve Harcama Takip Sistemi
Öğrenci: Mustafa Şükrü Egrıbaş
Numara: 24903003
Ders: BGY210 – Python Programlama II

Uygulamanın giriş noktası.
Tüm modülleri birleştirerek konsol menüsünü çalıştırır.

Kullanım:
    python main.py

GitHub Repo: https://github.com/<kullanici>/24903003-MustafaSukruEgribas-PythonProje
"""

import sys

from analiz import analiz_goster, aylik_tablo_guncelle
from dosya_islemleri import csv_menu, excel_menu
from finans_modeli import FinansYoneticisi
from gorsellestirme import grafik_menu
from islem_yonetimi import gelir_ekle, gider_ekle, islem_sil, islemleri_listele
from utils import baslik_yazdir, menu_goster


# ---------------------------------------------------------------------------
# Yardımcı: otomatik CSV yükleme
# ---------------------------------------------------------------------------

def _baslangic_yukleme(yonetici: FinansYoneticisi) -> None:
    """
    Uygulama açılırken varsayılan CSV varsa otomatik yükler.
    Kullanıcı onayı gerektirmez; sessizce çalışır.
    """
    import os
    from dosya_islemleri import VARSAYILAN_CSV, csv_oku

    if os.path.exists(VARSAYILAN_CSV):
        print(f"\n  ℹ '{VARSAYILAN_CSV}' bulundu, veriler yükleniyor...")
        csv_oku(yonetici, VARSAYILAN_CSV)


# ---------------------------------------------------------------------------
# Ana döngü
# ---------------------------------------------------------------------------

def main() -> None:
    """
    Uygulamanın ana giriş noktası.
    Menüyü döngüsel olarak gösterir ve kullanıcı seçimine göre
    ilgili modül fonksiyonunu çağırır.
    """
    # Merkezi veri yöneticisi – tüm işlemler burada tutulur
    yonetici = FinansYoneticisi()

    print("\n" + "═" * 55)
    print("  Kişisel Finans ve Harcama Takip Sistemi")
    print("  Mustafa Şükrü Egrıbaş – 24903003 – BGY210")
    print("═" * 55)

    # Önceki veriler varsa yükle
    _baslangic_yukleme(yonetici)

    # Ana menü döngüsü
    while True:
        menu_goster()
        secim = input("  Seçiminiz: ").strip()

        if secim == "1":
            # ── Gelir Ekle ────────────────────────────────────────────
            gelir_ekle(yonetici)

        elif secim == "2":
            # ── Gider Ekle ────────────────────────────────────────────
            gider_ekle(yonetici)

        elif secim == "3":
            # ── Listele ───────────────────────────────────────────────
            islemleri_listele(yonetici)

        elif secim == "4":
            # ── Analiz Yap ────────────────────────────────────────────
            analiz_goster(yonetici)

        elif secim == "5":
            # ── Grafik Göster ─────────────────────────────────────────
            grafik_menu(yonetici)

        elif secim == "6":
            # ── CSV Kaydet / Yükle ────────────────────────────────────
            csv_menu(yonetici)

        elif secim == "7":
            # ── Excel'e Aktar ─────────────────────────────────────────
            baslik_yazdir("Excel'e Aktar")
            excel_menu(yonetici)

        elif secim == "8":
            # ── İşlem Sil ─────────────────────────────────────────────
            islem_sil(yonetici)

        elif secim == "9":
            # ── Aylık Tabloyu Güncelle ────────────────────────────────
            aylik_tablo_guncelle(yonetici)

        elif secim == "0":
            # ── Çıkış ─────────────────────────────────────────────────
            baslik_yazdir("Programdan Çıkış")
            from dosya_islemleri import VARSAYILAN_CSV, csv_kaydet
            from utils import onay_al

            if yonetici.tum_islemler():
                if onay_al("  Çıkmadan önce veriler CSV'ye kaydedilsin mi? (e/h): "):
                    csv_kaydet(yonetici, VARSAYILAN_CSV)

            print("\n  👋 Görüşmek üzere, Mustafa Şükrü!\n")
            sys.exit(0)

        else:
            print("  ⚠ Geçersiz seçim. Lütfen menüden bir numara girin.")

        input("\n  [Enter] ile devam edin...")


# ---------------------------------------------------------------------------
# Giriş noktası
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n  ⚠ Program kullanıcı tarafından sonlandırıldı.")
        sys.exit(0)
