"""
utils.py
--------
Proje: Kişisel Finans ve Harcama Takip Sistemi
Öğrenci: Mustafa Şükrü Egrıbaş
Numara: 24903003
Ders: BGY210 – Python Programlama II

Yardımcı (utility) fonksiyonlar.
Doğrulama, ID üretme ve menü gösterimi bu modülde yer alır.
"""

from datetime import datetime


# ---------------------------------------------------------------------------
# Sabitler
# ---------------------------------------------------------------------------

TARIH_FORMATI = "%Y-%m-%d"

GELİR_KATEGORİLERİ = [
    "Maaş", "Serbest Çalışma", "Kira Geliri",
    "Yatırım", "Burs", "Diğer Gelir",
]

GİDER_KATEGORİLERİ = [
    "Market", "Faturalar", "Kira", "Ulaşım",
    "Sağlık", "Eğlence", "Eğitim", "Giyim",
    "Restoran", "Teknoloji", "Diğer Gider",
]


# ---------------------------------------------------------------------------
# Yardımcı fonksiyonlar
# ---------------------------------------------------------------------------

def yeni_id_olustur(liste: list) -> int:
    """
    Verilen listedeki en büyük ID değerini bulup bir artırır.
    Liste boşsa 1 döndürür.

    Args:
        liste: Islem nesnelerinden oluşan liste.

    Returns:
        Yeni benzersiz tam sayı ID.
    """
    if not liste:
        return 1
    return max(islem.id for islem in liste) + 1


def tum_listelerden_yeni_id(gelirler: list, giderler: list) -> int:
    """
    Hem gelir hem de gider listesini dikkate alarak benzersiz ID üretir.

    Args:
        gelirler: Gelir işlemleri listesi.
        giderler: Gider işlemleri listesi.

    Returns:
        Yeni benzersiz tam sayı ID.
    """
    tum_islemler = gelirler + giderler
    return yeni_id_olustur(tum_islemler)


def tarih_kontrol(tarih: str) -> bool:
    """
    Verilen tarihin YYYY-MM-DD formatında geçerli olup olmadığını kontrol eder.

    Args:
        tarih: Kontrol edilecek tarih dizisi.

    Returns:
        True → geçerli, False → geçersiz.
    """
    try:
        datetime.strptime(tarih, TARIH_FORMATI)
        return True
    except ValueError:
        return False


def sayi_kontrol(deger: str) -> bool:
    """
    Verilen dizinin pozitif sayıya dönüştürülebilir olup olmadığını kontrol eder.

    Args:
        deger: Kontrol edilecek dizi.

    Returns:
        True → geçerli pozitif sayı, False → geçersiz.
    """
    try:
        sayi = float(deger)
        return sayi > 0
    except ValueError:
        return False


def bugun_tarihi() -> str:
    """Bugünün tarihini YYYY-MM-DD formatında döndürür."""
    return datetime.today().strftime(TARIH_FORMATI)


def kategori_sec(tip: str) -> str:
    """
    Kullanıcıya numaralı liste göstererek kategori seçtiren fonksiyon.

    Args:
        tip: 'gelir' veya 'gider'

    Returns:
        Seçilen kategori adı.
    """
    kategoriler = GELİR_KATEGORİLERİ if tip == "gelir" else GİDER_KATEGORİLERİ
    print("\n  Kategori Seçin:")
    for i, kat in enumerate(kategoriler, 1):
        print(f"    {i}. {kat}")

    while True:
        secim = input("  Seçiminiz (numara): ").strip()
        if secim.isdigit() and 1 <= int(secim) <= len(kategoriler):
            return kategoriler[int(secim) - 1]
        print("  ⚠ Geçersiz seçim, tekrar deneyin.")


def kullanici_tarih_al(mesaj: str = "  Tarih (YYYY-MM-DD) [boş = bugün]: ") -> str:
    """
    Kullanıcıdan geçerli tarih alır; boş girişte bugünün tarihini kullanır.

    Args:
        mesaj: Ekrana yazdırılacak soru metni.

    Returns:
        Geçerli tarih dizisi (YYYY-MM-DD).
    """
    while True:
        tarih = input(mesaj).strip()
        if tarih == "":
            tarih = bugun_tarihi()
            print(f"  ℹ Tarih otomatik atandı: {tarih}")
            return tarih
        if tarih_kontrol(tarih):
            return tarih
        print("  ⚠ Geçersiz tarih formatı. Lütfen YYYY-MM-DD girin.")


def kullanici_tutar_al(mesaj: str = "  Tutar (TL): ") -> float:
    """
    Kullanıcıdan geçerli pozitif tutar alır.

    Args:
        mesaj: Ekrana yazdırılacak soru metni.

    Returns:
        Pozitif float tutar.
    """
    while True:
        deger = input(mesaj).strip().replace(",", ".")
        if sayi_kontrol(deger):
            return float(deger)
        print("  ⚠ Lütfen pozitif bir sayı girin.")


def menu_goster() -> None:
    """Uygulamanın ana menüsünü ekrana yazdırır."""
    print("\n" + "═" * 55)
    print("  💰  KİŞİSEL FİNANS TAKİP SİSTEMİ")
    print("      Mustafa Şükrü Egrıbaş – 24903003")
    print("═" * 55)
    print("  1  ➜  Gelir Ekle")
    print("  2  ➜  Gider Ekle")
    print("  3  ➜  İşlemleri Listele")
    print("  4  ➜  Analiz Yap")
    print("  5  ➜  Grafik Göster")
    print("  6  ➜  CSV Kaydet / Yükle")
    print("  7  ➜  Excel'e Aktar")
    print("  8  ➜  İşlem Sil")
    print("  9  ➜  Aylık Tabloyu Güncelle (Manuel)")
    print("  0  ➜  Çıkış")
    print("═" * 55)


def baslik_yazdir(baslik: str) -> None:
    """Bölüm başlığını biçimli olarak ekrana yazdırır."""
    print(f"\n{'─' * 55}")
    print(f"  {baslik.upper()}")
    print(f"{'─' * 55}")


def onay_al(mesaj: str = "Devam etmek istiyor musunuz? (e/h): ") -> bool:
    """
    Kullanıcıdan evet/hayır onayı alır.

    Returns:
        True → evet, False → hayır.
    """
    yanit = input(mesaj).strip().lower()
    return yanit in ("e", "evet", "y", "yes")
